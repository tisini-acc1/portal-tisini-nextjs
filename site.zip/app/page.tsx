import HeroSection from "@/components/site/hero-section";

export default function Home() {
  return (
    <main>
      <HeroSection />
    </main>
  );
}
