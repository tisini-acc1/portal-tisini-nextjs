import React from "react";

const SummaryTable = () => {
  return <div>SummaryTable</div>;
};

export default SummaryTable;
