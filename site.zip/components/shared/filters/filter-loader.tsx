const FilterLoader = () => {
  return (
    <div className="h-10 w-[150px] mr-8 bg-gray-100 rounded-md animate-pulse" />
  );
};

export default FilterLoader;
